let searchForm = document.querySelector(".search-form");

document.querySelector('#search-bar').onclick = () =>{
    searchForm.classList.toggle('active');
}


let shoppingCart = document.querySelector(".shopping-cart");

document.querySelector('#cart-bar').onclick = () =>{
    shoppingCart.classList.toggle('active');
}

